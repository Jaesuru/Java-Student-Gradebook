/* This is part of the starter code!
 * You need to complete this class yourself!*/
package util;

public class Grade {
    public static final int A_CUTOFF_POINT = 95;
    public static final int AMINUS_CUTOFF_POINT = 90;
    public static final int B_CUTOFF_POINT = 85;
    public static final int BMINUS_CUTOFF_POINT = 80;
    public static final int C_CUTOFF_POINT = 75;
    public static final int CMINUS_CUTOFF_POINT = 70;
    public static final int D_CUTOFF_POINT = 65;
    public static final int DMINUS_CUTOFF_POINT = 60;

    private int score;
    private String letterGrade;

    public int getScore() { // Getter for score
        return score;
    }

    public String getLetterGrade() { // Getter for letterGrade
        return letterGrade;
    }

    public Grade(int score) { // Constructor for Grade
        this.score = score;
        this.letterGrade = scoreToLetter(score);
    }

    public static String scoreToLetter(double number) { // Method that converts given score into a letter.
        if (number >= A_CUTOFF_POINT)
            return "A";
        if (number >= AMINUS_CUTOFF_POINT)
            return "A-";
        if (number >= B_CUTOFF_POINT)
            return "B";
        if (number >= BMINUS_CUTOFF_POINT)
            return "B-";
        if (number >= C_CUTOFF_POINT)
            return "C";
        if (number >= CMINUS_CUTOFF_POINT)
            return "C-";
        if (number >= D_CUTOFF_POINT)
            return "D";
        if(number >= DMINUS_CUTOFF_POINT)
            return "D-";
        return "F";
    }
}
