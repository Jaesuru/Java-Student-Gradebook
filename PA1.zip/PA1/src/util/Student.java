/* This is part of the starter code!
 * You need to complete this class yourself!*/
package util;

/*
...
 */
public class Student {
    private String firstName;
    private String lastName;
    private int pid;
    private Grade grade;

    public String getFirstName() { // Getter for firstName
        return firstName;
    }

    public String getLastName() { // getter for lastName
        return lastName;
    }

    public int getPid() { // Getter for pid
        return pid;
    }

    public void setGrade(Grade grade) { // Setter for changing grade
        this.grade = grade;
    }

    public Student(String firstName, String lastName, int pid, Grade grade) { // Constructor for Student
        this.firstName = firstName;
        this.lastName = lastName;
        this.pid = pid;
        this.grade = grade;
    }

    public Grade getGrade() { // Getter for grade from Grade class.
        return grade;
    }
}
