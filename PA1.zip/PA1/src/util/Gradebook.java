/* This is part of the starter code!
 * You need to complete this class yourself!*/
package util;

import java.sql.SQLOutput;
import java.util.*;

public class Gradebook {
    public Gradebook() {
        listOfStudents = new ArrayList<>();
    }

    private ArrayList<Student> listOfStudents; // Arraylist of all students listed.

    public ArrayList<Student> getListOfStudents() { // Getter for the arraylist for all students.
        return listOfStudents;
    }

    public double calculateAvg() { // Method for calculating average of all student's grades within arraylist.
        double sum = 0;
        for (Student s : listOfStudents)
            sum += s.getGrade().getScore();
        return sum / listOfStudents.size();
    }

    public boolean changeGrade(int pid, int newScore) { // Method for setting and changing grade to another one given a PID.
        for (Student s : listOfStudents)
            if (s.getPid() == pid) {
                s.setGrade(new Grade(newScore));
                return true;
            }
        return false;
    }

    public String findFullName(int pid){ // Method for finding full name of student given PID
        for(Student s : listOfStudents)
            if(s.getPid() == pid) {
                String fullName = s.getFirstName() + " " + s.getLastName();
                return "Student name is " + fullName + ".";
            }
        return "An error was detected. Wrong PID? Please try again.";
    }

    public String findGrade(int pid){ // Method for finding grade of student given PID
        for(Student s : listOfStudents)
            if(s.getPid() == pid) {
                String studentsGrade = s.getGrade().getLetterGrade();
                return "Student's grade is a(n) " + studentsGrade + ".";
            }
        return "An error was detected. Wrong PID? Please try again.";
    }

    public float calculateMedian() { // Method for calculating median of all students within arraylist
        int i = 0, n = listOfStudents.size();
        int[] scores = new int[n];
        for (Student s : listOfStudents)
            scores[i++] = s.getGrade().getScore();
        Arrays.sort(scores);
        if (n % 2 == 0)
            return (scores[n / 2] + scores[n / 2 - 1]) / 2.0f;
        else
            return scores[n / 2];
    }

    public void printAllStudents() { // Method for printing out firstName, lastName, pid, and grade of all students in arraylist.
        for (Student s : listOfStudents)
            System.out.printf("%-20s%-20s%-10d%-10d\n", s.getFirstName(), s.getLastName(), s.getPid(), s.getGrade().getScore());
    }

    public void printAllStudents2() { // Same as the first print method, but prints letter instead of score.
        for(Student s : listOfStudents)
            System.out.printf("%-20s%-20s%-10d%-10s\n", s.getFirstName(), s.getLastName(), s.getPid(), s.getGrade().getLetterGrade());

    }
}
