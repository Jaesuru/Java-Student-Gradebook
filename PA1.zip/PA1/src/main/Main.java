/* This is part of the starter code!
 * You need to complete this class yourself!*/
package main;

import util.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    //PROGRAM INPUT HANDLING PHASE
    public static void main(String[] args) {
        Gradebook gradebook = new Gradebook();

        Scanner in = new Scanner(System.in);

        System.out.println("Welcome to my grade book!");
        System.out.println("Please enter the information of the first student using the following format:");
        System.out.println("“firstName lastName PID grade”.");
        System.out.println("Press Enter when you are done.");
        System.out.println("------------------------------------------------------------------------------\n");

        while (true) { // while loop to check conditions of input
            String studentInfo = in.nextLine();

            if (studentInfo.equalsIgnoreCase("DONE"))
                break;
            String[] tokens = studentInfo.split(" ");
            if (tokens.length != 4) {
                System.out.println("Wrong input! Please try again");
                continue;
            }
            if (!checkFirstName(tokens[0])) {
                System.out.println("Wrong first name! Please try again");
                continue;
            }
            if (!checkLastName(tokens[1])) {
                System.out.println("Wrong last name! Please try again");
                continue;
            }
            if (!checkID(tokens[2])) {
                System.out.println("Wrong PID! Please try again");
                continue;
            }
            if (!checkScore(tokens[3])) {
                System.out.println("Wrong score! Please try again");
                continue;
            }
            Student student = new Student(tokens[0], tokens[1], Integer.parseInt(tokens[2]), new Grade(Integer.parseInt(tokens[3]))); // new instance of student object
            gradebook.getListOfStudents().add(student); // adds newly created student object into arraylist located in gradebook
            System.out.println("------------------------------------------------------------------------------\n");
            System.out.println("Student successfully added.\n");

            System.out.println("...\n");

            System.out.println("Please enter the information of the next student using the same format.");
            System.out.println("If there is no more students, please enter the keyword “DONE”.");
            System.out.println("Press Enter when you are done.");

            System.out.println("------------------------------------------------------------------------------\n");

        }

        //PROGRAM COMMAND HANDLING PHASE
        while (true) {
            printCommandList(); // Prints the list of commands that user can input.

            Scanner c1 = new Scanner(System.in);
            String command = c1.nextLine();

            if (command.equalsIgnoreCase("quit")) {
                break;

            }if (command.equalsIgnoreCase("tabLetters")) {
                gradebook.printAllStudents2();

            }if (command.equalsIgnoreCase("tabScores")) {
                gradebook.printAllStudents();

            }if (command.equalsIgnoreCase("medianScore")) {
                System.out.println("Median score of all students is: " + gradebook.calculateMedian());

            }if (command.equalsIgnoreCase("medianLetter")) {
                float median = gradebook.calculateMedian();
                String letterGrade = Grade.scoreToLetter(median);
                System.out.println("Median letter score of all students is: " + letterGrade);

            }if(command.equalsIgnoreCase("averageScore")) {
                double avgScr = gradebook.calculateAvg();
                System.out.printf("Average score of all students is: %.2f", avgScr);

            }if (command.equalsIgnoreCase("averageLetter")) {
                double avgScr = gradebook.calculateAvg();
                String letterGrade = Grade.scoreToLetter(avgScr);
                System.out.println("Average letter score of all students is: " + letterGrade);

            }else if (command.equalsIgnoreCase("changeScore")){ //Prints header twice
                handleChangeGrade(in, gradebook); // Calls in method that prints out statements asking for inputs and verifies it with another method using if-else statements.

            }else if (command.equalsIgnoreCase("findName")){ //Prints header twice
                System.out.println("Please enter the PID of the student to find their name.");
                int pidInput = in.nextInt();

                System.out.println(gradebook.findFullName(pidInput));

            }else if (command.equalsIgnoreCase("findGrade")) { //Prints header twice
                System.out.println("Please enter the PID of the student to find their grade.");
                int pidInput = in.nextInt();

                System.out.println(gradebook.findGrade(pidInput));

            }if (command.equalsIgnoreCase("minScore")){
                System.out.println("The minimum score in the gradebook is a(n) " + findMinimum(gradebook.getListOfStudents()) + ".");

            }if (command.equalsIgnoreCase("minLetter")){

                int tempMin = findMinimum(gradebook.getListOfStudents());
                String tempMinLet = Grade.scoreToLetter(tempMin);

                System.out.println("The minimum letter grade in the gradebook is a(n) " + tempMinLet + ".");

            }if (command.equalsIgnoreCase("maxScore")){
                System.out.println("The maximum score in the gradebook is a(n) " + findMaximum(gradebook.getListOfStudents()) + ".");

            }if (command.equalsIgnoreCase("maxLetter")){

                int tempMax = findMaximum(gradebook.getListOfStudents());
                String tempMaxLet = Grade.scoreToLetter(tempMax);

                System.out.println("The maximum letter grade in the gradebook is a(n) " + tempMaxLet + ".");
            }

        }
    } // End of main(String[] args)

    // Methods
    private static boolean checkScore(String token) { // Checks score input to see if it is a non-zero integer between 0-100.
        int grade = Integer.parseInt(token);
        if (grade >= 0 && grade <= 100)
            return true;
        return false;
    }

    private static boolean checkID(String token) { // Checks id input to see if it is seven digits and if it is not lead by 0's.
        if (token.length() != 7) {
            return false;
        }
        if (token.charAt(0) == '0') {
            return false;
        }
        return true;
    }

    private static boolean checkLastName(String token) { // Checks lastName input to see if first letter starts with a capital and if the rest of the letters are undercase. It also checks to see if lastName contains at most one dot.
        if (!Character.isUpperCase(token.charAt(0))) {
            return false;
        }

        int dotCount = 0;

        for (int i = 1; i < token.length(); i++) {
            char currentChar = token.charAt(i);

            if (currentChar == '.') {
                dotCount++;
                if (dotCount > 1)
                    return false;
            }else if(!Character.isLowerCase(token.charAt(i)))
                return false;
        }
        return true;
    }

    private static boolean checkFirstName(String token) { // Checks firstName input to see if first letter starts with a capital and if the other letters are undercase.
        if (!Character.isUpperCase(token.charAt(0)))
            return false;
        for (int i = 1; i < token.length(); i++)
            if (!Character.isLowerCase(token.charAt(i)))
                return false;
        return true;
    }

    public static int findMinimum(ArrayList<Student> students){ // Method for finding the minimum score or letter of gradebook arraylist.
        int min = students.get(0).getGrade().getScore();
        for(Student s : students){
            if(min > s.getGrade().getScore()){
                min = s.getGrade().getScore();
            }
        }
        return min;
    }

    public static int findMaximum(ArrayList<Student> students){ // Method for finding the maximum score or letter of gradebook arraylist.
        int max = students.get(0).getGrade().getScore();
        for(Student s : students){
            if(max < s.getGrade().getScore()){
                max = s.getGrade().getScore();
            }
        }
        return max;
    }

    public static void handleChangeGrade(Scanner in, Gradebook gradebook){ // Method for when user inputs "changeGrade." Compressed into a single method for easier reading.
        System.out.println("Please enter the PID of the student to change their grade.\n");
        int pidInput = in.nextInt();

        System.out.println("\nYour input is: " + pidInput + ". Please enter a new grade for the student.\n");
        int newScore = in.nextInt();

        if(!gradebook.changeGrade(pidInput, newScore)){
            System.out.println("An error was detected. Wrong PID? Please try again.");

        }else{
            System.out.println("Grade updated for " + pidInput + ".");
        }
    }

    private static void printCommandList() { // Prints out a list of commands that are used in the while(true) loop.
        System.out.println("\nPlease enter a new command.");
        System.out.println("------------------------------------------------------------------------------\n");

        System.out.println("The list of commands include:\n");
        System.out.printf("%-15s%-15s%-15s%-15s%n", "quit", "tabLetters", "tabScores", "medianLetter");
        System.out.printf("%-15s%-15s%-15s%-15s%n", "medianScore", "averageLetter", "averageScore", "changeScore");
        System.out.printf("%-15s%-15s%-15s%-15s%n", "findName", "findGrade", "maxLetter", "maxScore");
        System.out.printf("%-15s%-15s%-15s%-15s%n", "minLetter", "minScore", "", "");

        System.out.println("------------------------------------------------------------------------------");


    }

}